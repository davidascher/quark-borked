Ingredients

* 3/4 pounds (3 sticks) unsalted butter
* 3 cups uncooked rolled oats (don't use instant)
* 1 1/2 Tbsp all-purpose flour
* 1 tsp salt
* 1 3/4c sugar
* 2 tsp vanilla extract
* 2 large eggs, lightly beaten

Steps:

* heat oven to 325F.  Cover a baking sheet w/ parchment paper
* In a large saucepan over low heat, melt the butter.  Let cool a bit and add all remaining ingredients except the eggs.  Stir well to combine, then add the eggs.  Mix until thoroughly incorporated
* Place 1 1/2 tsp of batter at a time on the parchment, leaving at least 3 inches in between cookies.  Flatten batter into a circle w/ a back of a spoon (DA: not needed).  Bake for 13-15 minutes, or until just golden brown.  Cool on wire racks (DA: don't, they're too soft -- cool on counter)
