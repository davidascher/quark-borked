Ingredients

* 1 lb semisweet or bittersweet chocolate, broken into chunks
* 1 cup heavy cream
* 2 Tbsp sugar
* 2 Tbsp butter
* 1 tsp vanilla
* 1 or 2 Tbls dark rum, brandy, kahlua, grand marnier, or whatever

Steps:

1. combine butter, sugar, cream in a small saucepan
1. place on medium heat and stir until butter melts
1. heat until bubbles start to form and cream about to boil
1. pour over chocolate.
1. let sit for 30 seconds to soften the chocolate
1. stir until smooth & thick
1. stir in rum & vanilla
