Ingrédients:

* 4 oeufs (blanc en neige)
* 125 grammes de sucre
* 80 grammes de farine ou fécule de pommes de terre

Etapes:

1. bien travaille les jaunes + sucre
1. ensuite la farine
1. puis les blancs en douceur 