1 kg pommes

150 grammes pain sec et trempes

300 grammes de sucre

5 oeufs en tiers

huile

raisins trempes

maizena

1 1/2 h à 2h de cuisson 