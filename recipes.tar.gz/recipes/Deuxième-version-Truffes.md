200 grammes chocolat cacao

150 grammes beurre

50 grammes sucre

125 grammes amandes

kirsch, cointreau 