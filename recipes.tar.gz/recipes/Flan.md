2 gros oeufs ou 3 petits

1/2 litre lait

sucre vanille

bain marie 