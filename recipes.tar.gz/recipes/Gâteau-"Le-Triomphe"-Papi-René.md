100 grammes amandes pilées

125 grammes sucre

20 grammes de fécule

6 blancs d'oeufs

vanille

Piler les amandes melangés avec sucre

ajouter en plusieurs fois trois blancs non battus

Mettre la fécule et les autres blancs battus

Cuire la pâte en deux moules à tarte; mettre la crème au beurre entre les deux tartes

saupoudrer le sucre glace 