pour 1 jaune d'oeuf:

faire fondre 75 grammes sucre dans 1 c à soupe d'eau + 1/2 c à café alcool vinaigre

laisser refroidir

battre 65 grammes de beurre avec jaune d’oeuf

ajouter peu à peu le sirop refroidi

monter comme une mayonnaise 