Ingredients

* 1c flour
* 1/4 tsp baking powder
* 1 Tbsp sugar
* 1/4 tsp salt
* 1/2 c butter
* 3 cups apples, peeled & thinly sliced

Topping

* 1/2 c sugar (usually use less)
* 1/2 tsp cinnamon (usually use less)
* 1 egg yolk
* 3 Tbsp whipping cream

Steps

1. Preheat oven 350F
1. mix flour, baking powder, salt, sugar
1. cut in butter until mixture resembles coarse meal
1. Line 8 inch square pan with parchment paper or foil
1. Pat pastry into baking pan
1. Arrange apples on top of the dough
1. Combine sugar & cinnamon, sprinkle on apples
1. Beat egg yolk & cream, drizzle on apples
1. Bake 45 minutes, or until crust is golden & fruit is soft

Serve warm or cool. Serves 6
