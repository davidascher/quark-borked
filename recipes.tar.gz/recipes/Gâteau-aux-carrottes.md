même que [[Gâteau aux noisettes]] sauf

250 de carottes râpées en plus 