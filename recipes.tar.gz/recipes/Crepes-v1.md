### Ingredients

* 2 cups flour
* 3 eggs
* 3 cups milk (whole milk better, 2% ok)
* 3 tablespoons melted butter

### Steps
1. mix flour + eggs + butter + little bit of milk.
1. stir adding milk if it gets too dry.  Mix thoroughly to remove lumps.
1. Add the rest of the milk in 3 steps..
1. _ideally_ let stand if possible whole day at 4 degrees C.
1. _alternative recipe_ replace 1 cup of milk w/ 1 cup of beer.
