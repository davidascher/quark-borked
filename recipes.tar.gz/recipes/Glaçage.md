* 125 grammes de chocolat pour les gâteaux
* 50 grammes de beurre
* 50 grammes de sucre glace

mélanger et étaler sur le gâteau immédiatement 

Recette de Dani.