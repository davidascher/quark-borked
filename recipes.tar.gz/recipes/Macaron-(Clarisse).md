70 grammes sucre

70 grammes amandes

1 blanc d'oeuf en neige

pour 1 gâteau moyen x 3

pour un petit moule a tarte; cuisson 20 min 