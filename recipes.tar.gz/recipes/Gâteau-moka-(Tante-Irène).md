8 oeufs

2 p levure

2 p de vanille

350 grammes sucre

3 verres d'huile (verre à vodka)

2 verres cognac (verre à vodka)

150 grammes fécule pommes de terre

200 grammes farine fluide

Mélanger jaunes + sucre + vanille

ajouter cognac + l'huile peu à peu la farine, levure

blancs en neige

Four froid à 160 degrés pendant 40 min

Démouler sur torchon mouillée

laisser refroidir

Asperger gâteau de café + sucre + cognac

Crème au beurre:

    jaunes d'oeufs
    sucre glace
    essence de café
    noix 