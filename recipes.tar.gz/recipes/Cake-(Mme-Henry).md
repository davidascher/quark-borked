* 385 grammes farine
* 200 grammes sucre
* 1 pincée levure
* 1 pincée sucre vanille
* Mélanger:
* 4 jaunes d'oeufs
* 1 verre lait
* 2/3 verre d'huile
* blanc en neige
* amandes émondées au fond du moule
* four froid
* 1 h 1/2 à 145. 