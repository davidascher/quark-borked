* 3 oeufs entiers
* 250 de sucre
* 250 grammes de beurre
* 300 grammes de farine
* un paquet et demi de levure
* deux paquets de vanille
* 1/2 paquet de levure
* 1 demie tasse de lait

Note: utiliser un moule aux madeleines beurrées 