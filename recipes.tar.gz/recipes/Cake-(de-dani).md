### Ingrédients
* 300 grammes de farine
* 200 grammes de sucre
* 100 grammes de beurre
* 3 oeufs entiers
* 4 T de lait
* jus de citron (1/2 citron)
* un paquet de levure chimique

### Etapes
1. beurre + sucre bien mélanger
1. ensuite peu à peu les oeufs
1. ensuite farine et le reste
1. four moyen 