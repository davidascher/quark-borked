###Ingrédients
* 200 grammes sucre
* 75 grammes amandes effilées
* 75 grammes farine
* 1 jus d'orange
* 75 g beurre fondu
* 2 c à c de zeste d'orange

###Etapes
1. Mélanger sucre amande farine
1. jus d'orange, zeste
1. déposer sur tôle avec 1 c à café
1. étaler à l'aide d'une fourchette trempée dans l'eau
1. four 200 quelques minutes
1. déposer sur sopalin

NB: très bon avec de la glace 