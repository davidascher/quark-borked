Ingredients:

* 6 egg whites at room temp
* 1/2 tsp cream of tartar
* pinch of salt
* 1 cup superfine sugar
* 1 tsp vanilla
* 1 cup confectioner's sugar, sifted

Steps:

1. place 1 oven rack on middle shelf, preheat @ 200 Fahr.
1. Line 2 baking sheets w/ parchment paper
1. in a large bowl, beat the egg whites and cream of tartar with an electric mixer at low speed until
1. foamy.  add the salt and increase the mixer speed to medium high and continue beating until soft peaks form.  continue beating, adding the superfine sugar 1 Tbsp at a time until stiff, glossy peaks form.  Beat in the vanilla.
1. Sift the confectioner's sugar a second time, over the meringue.  Using a rubber spatula, carefully fold in until no streaks of sugar remain.  Do not fold any more than necessary.
1. 1/4 cup portions
1. bake for 2 hours or until crisp.
1. "when the meringues are crisp, turn the oven off and let them cool for 1 to 6 hours" (I never do)