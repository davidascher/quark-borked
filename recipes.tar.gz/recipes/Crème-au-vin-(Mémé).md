* 6 jaunes d'oeufs
* 2 petits verres de vin blanc ou champagne
* 1 citron
* sucre 150 grammes (sabayon) 