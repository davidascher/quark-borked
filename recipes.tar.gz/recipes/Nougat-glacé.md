Pour 6 personnes:

* 3 oeufs
* 120 grammes sucre
* 4 dl de crème fraîche liquide
* 1 c à soupe fleur d'oranger
* 100 grammes miel
* 125 d'amandes effilées
* 50 grammes de noisettes concassées ou pistaches non sales
* 80 grammes de raisons (ou abricots)

###Etapes:

1. Saupoudrez les amandes et les noisettes avec 3 c à soupe de sucre et les caraméliser, puis ajouter au mélange précèdent
1. Séparer les blancs des jaunes
1. les farines battre avec le reste du sucre 
1. ajouter blanc, fleur d'oranger 
1. les blancs en neige pendant ce temps 
1. chauffer le miel, l'incorporer aux blancs 
1. battre la crème en chantilly
1. mélanger doucement les jaunes et les blancs
1. incorporer la chantilly
1. ajouter les amandes, noisettes, raisins
1. mettre au congélateur 12 h minimum 