* 1 tasse de crème
* 1 pincée de sel ou sucre
* 1 tasse de farine 