### Olive Cheese Puffs (ca 1950)

Blend 1 cup grated cheddar with 3 tablespoons soft butter. Stir in 1/2 cup flour, 1/4 teaspoon salt, 1/2 teaspoon paprika.  Will be very dry and crumbly.

Thoroughly dry 24-48 pimento stuffed olives (depending on size). Wrap approximately 1 teaspoon cheese dough around each olive, covering completely. Put crumbly dough in palm of hand and mash with your thumb - it will cohere with body heat. Then wrap around olive.

Can be frozen for up to 1 week.

Bake at 400 for 10 minutes, until golden.

This takes longer to do than you might think.
