###Ingrédients
* 100 grammes sucre
* 70 g de crème liquide
* 35 grammes de beurre demi sel
* 1/2 gousse de vanille fendue et grattée
* 110 grammes chocolat noir 70% cacao
* 270 grammes de crème liquide fouettée

###Etapes
1. Dans une casserole, fondre le sucre à sec en ajoutant petit à petit jusqu'au caramel fonce
1. refroidir avec le beurre en remuant
1. ajouter 70 grammes de crème liquide
1. faire bouillir le tout
1. verser sur le chocolat hache gros dans un saladier
1. refroidir
1. incorporer la crème battue
1. remettre 3 h au réfrigérateur 