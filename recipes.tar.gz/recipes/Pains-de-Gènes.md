125 grammes sucre poudre

100 grammes beurre

100 grammes farine

zeste d'orange

1 c à c beurre

1 jus d'orange

four doux 40-50 min 