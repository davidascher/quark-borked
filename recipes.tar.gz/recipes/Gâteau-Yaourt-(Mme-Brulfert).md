* 1 pot de yaourt
* 2 pots de sucre
* 1 pot d'huile
* 3 pots de farine
* 1 pincée de levure
* 3 oeufs entiers
* 1 pomme en tranche
* four moyen 1/2 à 3/4 d'heure 