* 625 grammes de farine
* 250 grammes de sucre
* 65 grammes d’orangeade (fruits confits)
* 15 grammes de cannelle moulu)
* 12 grammes de levure alsacien
* 375 grammes de miel
* 65 grammes de citronnade (fruits confits)
* 90 grammes d’amandes coupes assez grossièrement
* 4 clous de girofles bien écrasés

### Etapes
1. mélanger le tout
1. laisser reposer une nuit
1. étaler assez fin sur les plats pâtissiers prédécoupés en carres
1. a la sortie du four mettre au pinceau sur les petits carres un mélange de blanc d’oeuf et de sucre glace très épais 