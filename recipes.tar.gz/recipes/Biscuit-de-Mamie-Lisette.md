* 4 oeufs (blanc en neige)
* 125 grammes de sucre en poudre
* 125 grammes de farine
* jus de citron
* sucre vanille 