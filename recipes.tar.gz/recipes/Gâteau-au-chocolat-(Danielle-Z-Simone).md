300 grammes suchard amer

200 grammes sucre

8 oeufs

50 grammes cacao

200 grammes beurre

Faire fondre chocolat + café + cognac

Incorporer jaunes

Partager mélange en deux

dans 1 moitié 50 grammes cacao + 3/4 blanc en neige

(l'autre quart dans l'autre moitié)

faire cuire premier mélange four moyen doux 30 min

napper avec l'autre moitié lorsque le gâteau est froid 