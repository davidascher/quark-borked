### Ingrédients
* 150 grammes de sucre
* 150 grammes de beurre
* 500 grammes farine
* 2 oeufs entiers
* cannelle + 1/2 paquet levure

### Etapes
1. Mélanger farine et jaunes + levure + cannelle
1. ajouter sucre et beurre fondu
1. blancs en neige (rouler la pâte , saupoudrer sucre 