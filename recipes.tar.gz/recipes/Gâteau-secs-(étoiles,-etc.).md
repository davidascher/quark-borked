* 750 grammes de beurre
* 250 grammes sucre
* 2 oeufs entiers
* 500 grammes farine 