500 grammes cerises cuits

3 jaunes d'oeufs, blanc en neige

sucre

125 grammes amandes

Verser sur les cerises

servir chaud 