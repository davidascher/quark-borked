###Ingrédients
* 20 cl crème fraîche
* 8 cl lait
* 200 grammes de chocolat noir
* 1 gros oeuf (légèrement battu)
* cacao non sucre

###Etapes
* 1 fond de tarte 23 cm cuit à blanc et refroidi
* cuire crème + lait jusqu'au ébullition
* retirer du feu
* ajouter chocolat
* remuer
* incorporer l'oeuf dans la crème froide
* fouetter
* verser dans le fond de tarte
* four à 190 12-15 min
* doit trembler au centre
* saupoudrer de cacao 