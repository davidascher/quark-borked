125 grammes de beurre

125 grammes de chocolat

2 jaunes d’oeuf

50 grammes de sucre glace

faire fondre le chocolat dans du café

rajouter la beurre ramollie dans le chocolat tiède

rajouter les jaunes d’oeuf

(on n’utilise pas les blancs ici)

ensuite laisser au frigo la nuit

roule dans le cacao et remettre au frigo

possible d’ajouter des amandes 