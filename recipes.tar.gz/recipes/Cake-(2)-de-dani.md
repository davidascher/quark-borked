### Ingredients
* 250 grammes de beurre
* 250 grammes de sucre
* 250 farine
* 4 oeufs entiers
* des raisins sec et des écorces d’orange (confits?) trempes dans du rhum ou un autre alcool une demie heure avant
* 1 paquet de levure

### Etapes
1. mélange beurre sucre
1. ensuite oeufs
1. ensuite farine et reste 