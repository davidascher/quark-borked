### Ingredients

* 1 cup butter, softened
* 1/2 cup powdered sugar
* 1 tsp. vanilla
* 2 1/2 cups flour
* 1/4 tsp. salt
* 3/4 cups finely chopped pecans
* extra powdered sugar for rolling/sprinkling

### Steps

* Preheat to 400.  
* Mix butter, sugar & vanilla.  
* Work in flour, salt and nuts until dough holds together (should be kind of crumbly but holds together from warmth of hands).  
* Shape into 1 inch balls.  
* Place on ungreased cookie sheet.  
* Bake 10-12 minutes until set but not brown.  
* While warm, roll in powdered sugar.  
* Cool & roll in sugar again (I sprinkle with a sifter).  
* Makes 4 dozen.
