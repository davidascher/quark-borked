* oeufs 1 à deux jaunes
* crème 20 cl liquide
* farine 1 c à soupe
* sucre 125 grammes + 25 (voir ci-dessous)
* cerises 1 sac griottes

Notes

* cuisson: 55 min à 175
* mettre 25 grammes sucre roux 