### Ingredients
* Un jaune d’oeuf
* 65 grammes de beurre
* 75 grammes de sucre
* 2 c à soupe d’eau
* 1 c à café de vinaigre d’alcool
* parfum au choix: essence de café, râpée du chocolat etc.
* 1 c à soupe de kirsch

### Etapes
1. mettre dans une casserole l’eau, sucre, vinaigre
1. faire un sirop cuire au filet
1. laisser refroidir sans le toucher
1. dans une terrine battre le beurre en crème sans fondre
1. ajouter les jaunes
1. ensuite le sirop (pas trop chaud)
1. ajouter le parfum
1. travailler jusqu’au ca soit lisse

### Sucre de petits fours
* 1/2 livre de sucre
* 1 c à café de vinaigre d'alcool
* 1 pincée de crème de tartre
* eau 