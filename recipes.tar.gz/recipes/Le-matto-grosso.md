pour deux gâteaux rectangulaires 20 cm

* 250 grammes chocolat
* 250 grammes beurre
* 250 grammes sucre
* 4 c à café fort
* 4 oeufs
* 1 c à soupe de farine
* 250 grammes de lait concentre
* pour glaçage 80 g chocolat + 60 grammes beurre

### Etapes
1. Chocolat + café + sucre feux doux
1. hors du feu incorporer beurre + oeufs battus + farine
1. faire cuire en bain marie 45 min
1. + four doux 20 min
1. reposer 24h
1. dans autocuiseur boite de lait 25 min
1. farcir le gâteau puis le glacer 