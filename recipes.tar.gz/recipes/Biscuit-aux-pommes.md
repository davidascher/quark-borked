2 oeufs battus (four 5/6 1/2 heure)

8 c à soupe sucre

12 c à soupe farine

1 pincée de levure

1 pince de sucre vanille

4 c à soupe huile

quartiers pommes ou poires

rhum 