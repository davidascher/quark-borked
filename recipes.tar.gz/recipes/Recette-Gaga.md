5 blancs d'oeufs

1 tasse sucre en poudre

3 c à soupe de levure alsacien

11 tasse de dates coupées

2 tasses de noix coupes 