* 60 grammes sucre glace tamise
* 60 grammes de beurre
* 2 gros oeufs
* 150 grammes farine tamisée
* sel 