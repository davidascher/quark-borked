* 4 oeufs entiers
* 75 grammes de beurre
* 1/2 paquet de levure
* sucre eau de fleur d'orange 