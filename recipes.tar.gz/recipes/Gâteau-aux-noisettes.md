Ingredients

* 7 jaunes d’oeufs (bien travaille)
* 250 grammes de sucre (bien mélanger avec l’oeuf)
* 250 grammes de noisettes moulinées
* 1/2 citron
* 1 Tsp vanille
* (kirsch optionnel)
* blancs en neige (7)
* four moyen; 45 min?

### Notes

* Hugo really likes this cake
* orange yolks yield very yellow cake
