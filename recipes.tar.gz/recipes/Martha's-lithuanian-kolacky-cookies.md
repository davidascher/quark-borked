(from Gus)

Ingredients

* 1 cup butter
* 1 8oz pkg cream cheese
* 1 Tb milk
* 1 Tb sugar
* 1 egg yolk, beaten
* 1 1/2 c all-purpose flour
* 1/2 tsp. baking powder 

Steps

1. Cream together butter, cream cheese, milk & sugar
1. Add beaten egg yolk
1. Sift together flour & baking powder
1. Add to cream cheese mixture & blend well.
1. Refrigerate 4hrs or overnight
1. Roll or pat out on well floured board to 1/4 inch and cut into 2" rounds
1. Place on ungreased cookie sheet and make depression with thumb or spoon
1. Fill with scan teaspoon filling
1. Bake at 400 for 10-15 minutes (martha does 12) or until lightly browned
1. Sprinkle with powdered sugar before serving. 

Makes 3 dozen 