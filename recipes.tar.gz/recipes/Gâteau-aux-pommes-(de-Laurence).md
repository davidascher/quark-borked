* 10 c à soupe de farine
* 8 c à soupe de sucre
* 6 c à soupe de l'huile
* 4 c à soupe de lait
* 2 oeufs
* 2 paquets de levure
* couper pommes lamelles
* recouvrir la pâte
* 25 min au four #4
* faire fondre 160 grammes de beurre et 200 grammes de sucre
* + 2 paquets de vanille
* Recouvrir le gâteau de cette pâte et cuire encore 15 à 20 min
* pour démouler recouvrir d'une assiette 