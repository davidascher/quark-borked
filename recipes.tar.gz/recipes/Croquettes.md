### Ingredients
* 250 grammes d'amandes
* 250 grammes sucre
* 1/2 verre crème
* 4 oeufs
* Glacer à l'eau sucrée

### Etapes
1. mélanger beurre + sucre
1. ensuite oeufs
1. ensuite farine
1. étaler la pâte sur deux grands plats pâtissiers avec une spatule
1. dessus verser une mélange cannelle + sucre
1. ensuite four moyen environs 30 min
1. sortir du four, et immédiatement couper en petit gâteau 