Faire exactement selon les données suivantes:

6 blancs en neige (pincée de sel)

y ajouter légèrement et rapidement

2 c à soupe de sucre glace

2 c à soupe de farine

2 jaunes d'oeufs

Dans le plat faire chauffer 60.100 grammes de beurre

mettre la préparation dans ce beurre chaud

faire cuire à four moyen pendant 7 à 10 min

(gold gelb) couleur jaune d'or

ne pas ouvrir le four pendant la cuisson

a la sortie du four, saupoudrer du sucre et servir aussitôt. 