* 175 grammes sucre
* 175 grammes farine
* 3 oeufs entiers
* 1 pincée de levure ...
* 100 grammes beurre
* 1 jus d'orange avec 100 grammes de sucre chauffes et verses sur gâteau cuit 