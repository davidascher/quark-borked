280 grammes farine

300 grammes miel

1 pincée de sel

50 grammes sucre

1 tasse à thé d'eau

noix

1 c à c bicarbonate

Faire fondre le miel dans l'eau en chauffant légèrement

ajouter 1 c à c pastis

Mélanger le tout

cuisson 1 h à four #3 