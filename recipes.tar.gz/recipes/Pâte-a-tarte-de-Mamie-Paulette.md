* 800 grammes de farine
* 250 grammes de beurre
* 1 verre de lait ou de l’eau
* 6 T l’huile
* du sel
* 3 T sucre 