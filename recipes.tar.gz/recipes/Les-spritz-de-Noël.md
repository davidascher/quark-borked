* 500 grammes de beurre
* 500 grammes de sucre
* 7 jaunes d’oeuf + un entier
* 500 grammes d’amandes sans peau et en farine
* 700 grammes de farine environs
* sucre vanillé

aplatir la pâte avant cuisson

couper en forme si vous voulez 