* 4 oeufs entiers
* 1 l de sucre
* 200 grammes d'amandes
* cannelle
* cacao
* sucre vanille
* écorce d'orange + citron

Etape

1. faire rouler
1. laisser reposer une nuit

puis:

* 1 kg farine
* 500 grammes beurre
* 6 oeufs
* 400 grammes sucre
* 1 paquet levure
* 1 paquet sucre vanille
* 1 c à soupe alcool

four à #6 12 min. 