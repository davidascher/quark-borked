### Crust

* 2/3c + 2 Tbsp shortening
* 2c flour
* 1 tsp salt
* 4-5 Tbsp cold water

### Peach Filling

* 425 fahr.
* 5c peaches (9 medium)
* 1 tsp lemon
* 1c sugar (maybe a bit less)
* 1/4c flour
* 1/4 tsp cinnamon
* 2 Tbsp butter

35-45min until brown and bubbly, cover edges with foil until last 15 min
(maybe less)

### Canned peaches: 
* 2 29oz cans,
*  1/2c less sugar

### Cherry filling

* 1 1/3c sugar
* 1/3c flour
* 2 16oz cans red tart cherries
* 1/4 tsp almon extract
* 2 Tbsp butter

### Frozen cherries
* 2 20oz cans frozen cherries thawed drained
* Only 1/2c sugar

### Blueberry (fresh)
* 1/2c sugar
* 1/3c flour
* 1/2 tsp cinnamon
* 4c fresh blueberries
* 1 Tbsp lemon juice
* 2 Tbsp butter
