* 1 kg pommes (petits morceaux)
* 150 grammes pain trempé
* 5 oeufs (blanc en neige)
* 300 grammes sucre
* 2 c de kirsch; raisins sec, amandes coupées 