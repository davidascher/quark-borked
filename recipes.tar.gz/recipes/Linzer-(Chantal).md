* 250 grammes farine
* 250 grammes sucre
* 250 grammes beurre
* 1 oeuf entier
* 2 c à café cannelle
* 8 clous de girofles écrasés
* zeste citron 