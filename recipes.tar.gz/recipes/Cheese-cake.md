170 grammes biscuit genre champagne

1 pincée cannelle

30 grammes sucre

100 grammes beurre

675 grammes fromage blanc

280 grammes sucre

6 jaunes d'oeuf

500 grammes crème

40 grammes farine

2 c à c vanille

1 c à soupe citron

1 c à soupe zeste citron

6 blancs en neige

(8-10 personnes) 