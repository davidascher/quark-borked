500 grammes purée de marrons

125 grammes de beurre

125 grammes de sucre

1 barre chocolat + café 