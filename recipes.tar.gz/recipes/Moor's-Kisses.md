See [meringue] and [ganache].

Make small kiss-shaped meringues with a pastry bag. When cool, poke hole in the bottom, fill with ganache, and dip in melted chocolate chips and dip in chocolate sprinkles

(couldn't get the melted chocolate chips to become dippable, so never got to that point) 