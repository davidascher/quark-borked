###Ingrédients
* 200 grammes farine
* 100 grammes sucre
* 100 grammes beurre en petits cubes
* 2 c à soupe lait
* 1 c à soupe porto
* 1 c café cannelle ou plus si vous voulez

###Etapes
1. Travaille la pâte le plus vite possible
1. l'étaler à la main dans le moule à tarte 30 cm - important!)
1. mettre au four 7-8 30 min
1. recouvrir de gelée de groseilles et remettre au four 3 min
1. découper tiède avant de démouler 