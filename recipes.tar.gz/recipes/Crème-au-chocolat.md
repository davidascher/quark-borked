5 oeufs blancs en neige

250 grammes de chocolat fondu dans le café

mélanger les jaunes et chocolat

ajouter les blancs en neige 