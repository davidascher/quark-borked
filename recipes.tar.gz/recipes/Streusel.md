Même recette que Kugelhof

+ le dessus:

100 grammes beurre

100 grammes sucre

cannelle

100 grammes farine 