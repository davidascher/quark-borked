## Kolacky Cookie
(from Augusta Bloom, Jonathan's Lithuanian mother -- way better than Polish Kolackies)

### Ingredients
* 1 cup butter, softened
* 8 oz package cream cheese, softened
* 1 Tbs. milk
* 1 Tbs. sugar
* 1 egg yolk, beaten
* 1 1/2 cups flour
* 1/2 tsp. baking powder
* Solo filling (poppy seed is traditional -- I like apricot and raspberry)

### Steps
1. Preheat to 400.  
1. Cream together butter, cream cheese, milk and sugar.  
1. Add beaten egg yolk.  
1. Sift together flour and baking powder.  
1. Add to cream cheese mixture and blend well.  
1. Refrigerate 4 hours or overnight.  
1. Roll or pat out on well-floured board to 1/4 inch and cut into 2 inch rounds.  
1. Place on ungreased cookie sheet and make depression with thumb or spoon.  
1. Fill with scant teaspoon filling.  
1. Bake for 10 - 15 minutes or until lightly browned.  
1. Sprinkle with powdered sugar before serving.  
1. Makes 3 dozen.