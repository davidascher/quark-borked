Pour 11 personnes

250 grammes de crème liquide

3 jaunes d'oeufs

80 grammes de sucre

1 c à soupe de maizena

250 g lait

sucre roux

Faire bouillir lait crème et sucre

laisser refroidir

battre les jaunes et le sucre

Mélanger à la première préparation

verser dans les ramequins

cuire au four bain marie 20 min thermostat #7

laisser refroidir
