Pour 1 oeuf de 60 grammes

50 grammes de sucre

10 grammes de farine

15 grammes de fécule

blancs en neige 