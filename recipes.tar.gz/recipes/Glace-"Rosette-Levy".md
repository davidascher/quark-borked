1/2 P de lait

200 grammes sucre

1 c à café maizena

4 jaunes d'oeuf

1/4 l crème

vanille (2 p)

sucre + lait - bouillir

jaunes délayés dans laid froid

verser dans le lait, laisser prendre

refroidir en tournant

ajouter crème fouettée 