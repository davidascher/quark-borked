250 grammes chocolat

1/2 litre café

1 oeuf entier

1 c à soupe maizena

Chauffer jusqu'au 1er bouillon

mettre dans les coupes 