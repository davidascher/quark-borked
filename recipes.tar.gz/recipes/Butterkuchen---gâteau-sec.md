* 250 grammes de beurre
* 200 grammes de sucre
* 3 oeufs entiers
* 350 grammes de farine 