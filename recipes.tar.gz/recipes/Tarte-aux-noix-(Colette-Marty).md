pâte sable (225 grammes farine, 100 grammes beurre, 50 grammes levure)

pétrir rapidement du bout des doigts

laisser reposer 1 à 2 heures

éteindre et garnir la moule à tarte diamètre 24 cm

garniture (250 g crème fraîche; 100 grammes sucre; 100 g poudre noix)

cuire à four moyen 30-35 min pas plus que 200 degrés

attention aux débordements)

glaçage (facultatif)

100 grammes sucre glace

1 blanc d'oeuf

2-3 c de kirsch 