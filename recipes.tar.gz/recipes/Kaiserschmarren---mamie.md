omelette de l'Empereur

Faire une pâte fluide mais pas trop avec:

250 grammes farine

1/4 litre de lait

Ajouter:

4 jaunes d'oeufs

50 grammes de beurre fondu

battre blancs en neige avec 30 grammes de sucre et ajouter à la pâte

Dans une poêle/Pyrex chauffe 10 grammes de beurre, et mettre la pâte

2 à 3 cm

parsemer de quelques sultanes et cuire à four chaud

A la sortie du four, déchirer la masse avec fourchettes pour la faire évaporer (pas trop longtemps pour qu'elle ne sèche pas)

saupoudre de sucre et servir avec une compote. 