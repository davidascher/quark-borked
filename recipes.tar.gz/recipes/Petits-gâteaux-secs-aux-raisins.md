pour chaque blanc d'oeuf:

* 25 grammes beurre
* 25 grammes sucre
* 25 grammes farine
* 25 grammes raisins

four 150 