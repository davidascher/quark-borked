* (12 tartelettes) (four doux 1/2 heure)
* 2 citrons (jus + zeste râpé)
* 400 grammes de sucre
* 6 oeufs entiers
* 100 grammes beurre et un peu d'eau 