250 grammes noix

200 grammes sucre

5 oeufs

Moudre les noix

mettre dans un récipient jaunes + sucre

tourner - blanchisse

mettre les noix peu à peu

battre blancs, ajouter au mélange

four déjà chaud

1/2 heure de cuisson four moyen

quand monter recouvrer

glaçage au café (sucre glace + café?) 