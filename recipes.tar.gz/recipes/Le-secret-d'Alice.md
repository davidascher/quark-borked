four moyen

* 3 oeufs
* 300 grammes sucre
* 2.5 dl l'huile
* 500 grammes carottes
* 210 grammes farine
* 1 sachet de levure
* 1 pincée muscade
* 100 grammes noisette
* 70 grammes noix
* 50 grammes sucre glace
* 50 grammes amandes effiles 