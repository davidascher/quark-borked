(From the Mangiaficos)

### Ingredients

* 2 eggplant diced w/ peel salted and drained
* 1 large onion chopped
* 3 stalks celery diced
* 28 oz can tomatoes
* 1/2c or more sicilian olievs mashed, pits removed (or plain green pitted)
* pine nuts
* 1/4 c red wine vinegar
* 1/2 c capers
* 2 T sugar
* olive oil

### Steps
* coat eggplant w/ olive oil, brown under broiler, stirring once.
* saute onion, celery in olive oil
* combine with eggplant, tomatoes, rest of ingredients
* cook together about 1/2h before cooking drain off some liquid if desired