2 oeufs

1 tasse sucre

2 1/2 barres chocolat

80 grammes beurre

1/2 c vanille

1/2 tasse farine

1/2 c levure alsacien

1 pincée de sel

1 tasse de noix

battre les oeufs entiers avec le sucre

chocolat au bain marie

tout mélanger - noix en dernier

four moyen 30 min. 