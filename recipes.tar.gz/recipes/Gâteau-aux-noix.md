5 oeufs (blancs en neige)

200 grammes sucre

250 grammes noix haches

40 g farine

1 c à soupe rhum

Mélanger jaunes + sucre + noix + farine

blancs en neige

rhum

four 180 degrés 20 min

dans moule à manquer 