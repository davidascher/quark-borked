* 4 oeufs entiers
* 500 grammes sucre
* 200 grammes amandes avec peau
* écorces d'orange, citron
* cannelle, girofles râpés, sucre
* vanille, cacao, levure 