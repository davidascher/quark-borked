6 jaunes d’oeufs

2 petits verres de vin blanc ou de champagne

1 jus de citron (un citron entier)

150 grammes de sucre

mélanger sucre et jaunes d’oeufs

chauffer le vin blanc ensuite ajouter aux jaunes d’oeufs mélangés

REGARDER RECETTE 