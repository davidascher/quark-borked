Pâte brisée (cuire la pâte)

bouillir 1 tasse d'eau + noix de beurre

Dans un bol mélanger 1 c à soupe farine

1 c à soupe maizena

3/4 livre de sucre

jeter eau + beurre sur mélange

ajouter 3 jaunes d'oeufs + jus et zeste de 2 citrons

verser tout le mélange dans casserole - épaisse

laisser refroidir

mettre blancs d'oeufs

repasser quelques minutes au four 