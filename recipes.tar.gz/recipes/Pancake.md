1 tasse + 1/4 lait

1 tasse + 1/2 de farine

2 oeufs entiers

1 c à café 3/4 levure

1 c à café sel

3 c à soupe sucre

2 c à soupe beurre 