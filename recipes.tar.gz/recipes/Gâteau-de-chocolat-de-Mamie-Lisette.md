### Ingrédients
* 250 grammes de chocolat ménager fondu dans du café fort (2T)
* 250 grammes de sucre
* 250 grammes de beurre
* 6 oeufs (blanc en neige)
* 50 grammes de farine

### Etapes
1. travailler jaunes d’oeufs, sucre, beurre ramollie dans chocolat fondu
1. ajouter la farine et ensuite blanc en neige
1. four: moyen jusqu’au pas d'adhérence
1. mettre dans le four un casserole d’eau 