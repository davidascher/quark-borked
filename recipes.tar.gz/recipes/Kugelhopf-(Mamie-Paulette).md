* four 150 environ 1 heure
* 1 kilo de farine
* 250 grammes de beurre
* 350 grammes de sucre
* 3 jaunes d’oeuf
* un pain (100 grammes – un ou deux paquets) de levure de boulanger
* du sel
* 200 grammes de raisin trempes en alcool

Etapes

1. moule à kugelhopf
1. mettre une dizaine d’amandes au fond du moule
1. four à 150 C environ une heure 