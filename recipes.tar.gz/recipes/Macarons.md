* 6 blancs en neige ferme
* 500 grammes de sucre
* 500 grammes d'amandes râpées 