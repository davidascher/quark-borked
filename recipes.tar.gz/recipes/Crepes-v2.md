* 6 tablespoons butter -- browned
* 3 cups milk - scalded & cooled
* 6 eggs - beaten
* 1 1/2 cups flour
* 7 tablespoons sugar
* Pinch salt 

flour + sugar + salt + eggs + milk + butter
