250 grammes de farine

2 T l’huile

125 grammes de beurre fondu

8 oeufs entiers

sel

lait

bière

vanille 