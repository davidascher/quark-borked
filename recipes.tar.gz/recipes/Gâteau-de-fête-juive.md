1 verre de dates dénoyautés

1 verre de raisins secs

1 verre de figues séchées

200 grammes de beurre

200 grammes de sucre

4 oeufs

300 grammes farine

1 sache levure

1/2 verre de noix

1/2 verre de vin

1 zeste de citron

mettre dattes, beurre, sucre, citron dans une casserole

chauffer

par ailleurs farine, levure, oeufs, noix amandes, vin, hors du feux

mélanger les deux préparations

1 heure au four #6 